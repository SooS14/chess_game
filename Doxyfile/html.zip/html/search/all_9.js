var searchData=
[
  ['_7echessboard',['~Chessboard',['../classChessboard.html#a53eac522998d8d92cca409493c773f54',1,'Chessboard']]]
];
