var searchData=
[
  ['pawn',['Pawn',['../classPawn.html',1,'']]],
  ['piece',['Piece',['../classPiece.html',1,'']]]
];
