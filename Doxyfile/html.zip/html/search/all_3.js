var searchData=
[
  ['is_5fthat_5flegal',['is_that_legal',['../classChessboard.html#a12ff4ac86a41d525388465e1a552fa11',1,'Chessboard']]]
];
