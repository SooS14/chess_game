var searchData=
[
  ['queen',['Queen',['../classQueen.html',1,'']]]
];
