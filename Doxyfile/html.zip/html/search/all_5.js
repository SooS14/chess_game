var searchData=
[
  ['move_5fpieces',['move_pieces',['../classChessboard.html#a7db1f0aa2670e9183b5753386f10ac7d',1,'Chessboard']]]
];
