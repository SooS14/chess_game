var searchData=
[
  ['chessboard',['Chessboard',['../classChessboard.html#a0647fd37fc04def4958a586c3d0100ab',1,'Chessboard']]]
];
