var searchData=
[
  ['bishop',['Bishop',['../classBishop.html',1,'']]]
];
