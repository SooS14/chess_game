var searchData=
[
  ['deactivate_5fen_5fpassant_5fblack',['deactivate_en_passant_black',['../classChessboard.html#a7be80d7f0d3ea6ab343379a941e3cb5f',1,'Chessboard']]],
  ['deactivate_5fen_5fpassant_5fwhite',['deactivate_en_passant_white',['../classChessboard.html#a1061a56edf6eeb1185f9a538c5c2a065',1,'Chessboard']]]
];
