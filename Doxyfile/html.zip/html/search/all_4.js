var searchData=
[
  ['king',['King',['../classKing.html',1,'']]],
  ['knight',['Knight',['../classKnight.html',1,'']]]
];
